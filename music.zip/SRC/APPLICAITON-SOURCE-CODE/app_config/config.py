CONFIG = {
    "mysql": {
        "user": "DbMysql23",
        "pass": "DbMysql23",
        "database": "DbMysql23",
        "host": "mysqlsrv.cs.tau.ac.il",
        "tables": {
            "users": "Users"
        }
    },
    "webserver": {
        "ip": "localhost",
        "port": 4000
    }
}
