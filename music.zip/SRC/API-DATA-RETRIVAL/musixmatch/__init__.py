from .musixmatch import Musixmatch
from .utils import _set_page_size